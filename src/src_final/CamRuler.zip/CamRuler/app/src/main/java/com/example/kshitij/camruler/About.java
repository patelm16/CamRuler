package com.example.kshitij.camruler;

import android.os.Bundle;

/**
 * Created by Kshitij on 2017-11-29.
 */

public class About extends MainActivity {

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
    }
}
